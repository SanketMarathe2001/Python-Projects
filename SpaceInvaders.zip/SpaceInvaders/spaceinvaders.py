import pygame
from pygame.locals import *
import sys
import random
from pygame import mixer


class SpaceInvaders:
    def __init__(self):

        # Intialization
        pygame.mixer.init()
        self.score = 0
        self.lives = 2
        self.string=""
        pygame.font.init()
        self.font = pygame.font.Font("assets/space_invaders.ttf", 15)
        self.font1 = pygame.font.Font('freesansbold.ttf', 50)

        # Barrier Design
        barrierDesign = [[],[0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0],
                         [0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0],
                         [0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0],
                         [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                         [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                         [1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1],
                         [1,1,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1],
                         [1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,1,1],
                         [1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,1,1],
                         [1,1,1,1,1,0,0,0,0,0,0,0,1,1,1,1,1]]

        # Screen Size
        self.screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption("Space Invader")

        # Icon
        icon = pygame.image.load('assets/ufo.png')
        pygame.display.set_icon(icon)

        self.enemySprites = {
                0:[pygame.image.load("assets/a1_0.png").convert(), pygame.image.load("assets/a1_1.png").convert()],
                1:[pygame.image.load("assets/a2_0.png").convert(), pygame.image.load("assets/a2_1.png").convert()],
                2:[pygame.image.load("assets/a3_0.png").convert(), pygame.image.load("assets/a3_1.png").convert()],
                }
        self.player = pygame.image.load("assets/shooter.png").convert()
        self.title = pygame.image.load("assets/title.jpg")
        self.arrow_left = pygame.image.load("assets/arrow_left.png")
        self.arrow_right = pygame.image.load("assets/arrow_right.png")
        self.spacebar = pygame.image.load("assets/spacebar.png")
        self.animationOn = 0
        self.direction = 1
        self.enemySpeed = 20
        self.lastEnemyMove = 0
        self.playerX = 400
        self.playerY = 550
        self.bullet = None
        self.bullets = []
        self.enemies = []
        self.barrierParticles = []
        self.textSurface = None
        startY = 50
        startX = 50
        for rows in range(6):
            out = []
            if rows < 2:
                enemy = 0
            elif rows < 4:
                enemy = 1
            else:
                enemy = 2
            for columns in range(10):
                out.append((enemy,pygame.Rect(startX * columns, startY * rows, 35, 35)))
            self.enemies.append(out)
        self.chance = 990

        barrierX = 50
        barrierY = 400
        space = 100

        # Barrier Positions
        for offset in range(1, 5):
            for b in barrierDesign:
                for b in b:
                    if b != 0:
                        self.barrierParticles.append(pygame.Rect(barrierX + space * offset, barrierY, 5,5))
                    barrierX += 5
                barrierX = 50 * offset
                barrierY += 3
            barrierY = 400

    # Enemy Update(After bullet hits the Enemy)
    def enemyUpdate(self):
        if not self.lastEnemyMove:
            for enemy in self.enemies:
                for enemy in enemy:
                    enemy = enemy[1]

                    # Enemy Bullet hits Player
                    if enemy.colliderect(pygame.Rect(self.playerX, self.playerY, self.player.get_width(), self.player.get_height())):
                        self.lives -= 1
                        self.resetPlayer()
                    enemy.x += self.enemySpeed * self.direction
                    self.lastEnemyMove = 25

                    # Enemy Boundary
                    if enemy.x >= 750 or enemy.x <= 0:
                        self.moveEnemiesDown()
                        self.direction *= -1
                    
                    chance = random.randint(0, 1000)

                    # Enemy Shoots Bullet
                    if chance > self.chance:
                        self.bullets.append(pygame.Rect(enemy.x, enemy.y, 5, 10))
                        self.score += 5
            if self.animationOn:
                self.animationOn -= 1                                                                                                                                                        
            else:
                self.animationOn += 1
        else:
            self.lastEnemyMove -= 1
    
    # Movement of Enemies
    def moveEnemiesDown(self):
        for enemy in self.enemies:
            for enemy in enemy:
                enemy = enemy[1]
                enemy.y += 20

    # PLayer's Movements
    def playerUpdate(self):
        key = pygame.key.get_pressed()
        if key[K_RIGHT] and self.playerX < 800 - self.player.get_width():
            self.playerX += 5
        elif key[K_LEFT] and self.playerX > 0:
            self.playerX -= 5
        if key[K_SPACE] and not self.bullet:

            # Bullet Sound
            bulletSound = mixer.Sound("assets/laser.wav")
            bulletSound.play()
            self.bullet = pygame.Rect(self.playerX + self.player.get_width() / 2- 2, self.playerY - 15, 5, 10)

    # Bullets Creation
    def bulletUpdate(self):

        # Player Bullet hits Enemy
        for i, enemy in enumerate(self.enemies):
            for j, enemy in enumerate(enemy):
                enemy = enemy[1]
                if self.bullet and enemy.colliderect(self.bullet):

                    # Enemy Collision Sound
                    explosionSound = mixer.Sound("assets/explosion.wav")
                    explosionSound.play()
                    self.enemies[i].pop(j)
                    self.bullet = None
                    self.chance -= 1
                    self.score += 100

        # Enemy Bullet Speed
        if self.bullet:
            self.bullet.y -= 20
            if self.bullet.y < 0:
                self.bullet = None

        for x in self.bullets:
            x.y += 20

            # Bullet Boundary
            if x.y > 600:
                self.bullets.remove(x)

            # Bullet hits Player
            if x.colliderect(pygame.Rect(self.playerX, self.playerY, self.player.get_width(), self.player.get_height())):
                self.lives -= 1
                self.bullets.remove(x)
                self.resetPlayer()

        # Bullets Hits Barriers
        for b in self.barrierParticles:
            check = b.collidelist(self.bullets)
            if check != -1:
                self.barrierParticles.remove(b)
                self.bullets.pop(check)
                self.score += 10
            elif self.bullet and b.colliderect(self.bullet):
                self.barrierParticles.remove(b)
                self.bullet = None
                self.score += 10

    # Reassign the position Player after been hit by Enemy's bullet
    def resetPlayer(self):
        self.playerX = 400

    # For Display Buttons on Screen
    def button(self,msg,x,y,w,h,ic,ac,action):
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        if x+w > mouse[0] > x and y+h > mouse[1] > y:
            pygame.draw.rect(self.screen,ac,(x,y,w,h))

            if click[0] == 1 and action != None:
                action()
        else:
            pygame.draw.rect(self.screen,ic,(x,y,w,h))

        TextSurf = self.font1.render(msg, True, (255, 255, 255))
        TextRect = TextSurf.get_rect()
        TextRect.center = ((x+(w/2)),(y+(h/2)))
        self.screen.blit(TextSurf,TextRect)

    # Menu
    def game_intro(self):
        clock = pygame.time.Clock()
        blue = (0,0,200)
        bright_blue = (0,0,255)
        green = (0,200,0)
        bright_green = (0,255,0)
        red = (200,0,0)
        bright_red = (255,0,0)
        while True:

            clock.tick(60)
            self.screen.fill((0, 0, 0))
            for event in pygame.event.get():
                if event.type == QUIT:
                    sys.exit()
            self.screen.blit(self.title,(80,0))
            self.button("Play",350,320,110,50,green,bright_green,self.game_loop)
            self.button("Instruction", 250, 380, 300, 50, blue, bright_blue, self.instruction)
            self.button("Quit", 350, 440, 110, 50, red, bright_red, self.gamequit)
            pygame.display.update()

    # Screen after Win or Lose
    def game_end_screen(self):
        clock = pygame.time.Clock()
        green = (0,200,0)
        bright_green = (0,255,0)
        red = (200,0,0)
        bright_red = (255,0,0)
        while True:

            clock.tick(60)
            self.screen.fill((0, 0, 0))
            for event in pygame.event.get():
                if event.type == QUIT:
                    sys.exit()

            if self.string == "You Win!!!":
                self.screen.blit(pygame.font.Font("assets/space_invaders.ttf", 100).render(self.string, -1, (52, 255, 0)), (150, 90))
            else:
                self.screen.blit(pygame.font.Font("assets/space_invaders.ttf", 100).render(self.string, -1, (52, 255, 0)), (100, 90))

            self.screen.blit(self.font.render("Score: {}".format(self.score), -1, (255, 255, 255)), (340, 215))
            self.button("Restart",300,250,190,50,green,bright_green,self.game_loop)
            self.button("Quit", 340, 310, 110, 50, red, bright_red, self.gamequit)
            pygame.display.update()

    # Instruction Menu
    def instruction(self):
        clock = pygame.time.Clock()
        green = (0, 200, 0)
        red = (200, 0, 0)
        bright_red = (255, 0, 0)
        while True:

            clock.tick(60)
            self.screen.fill((0, 0, 0))
            for event in pygame.event.get():
                if event.type == QUIT:
                    sys.exit()

            TextSurf = self.font1.render("INSTRUCTION", True, (255, 255, 255))
            TextRect = TextSurf.get_rect()
            TextRect.center = (400,100)
            self.screen.blit(TextSurf, TextRect)

            pygame.draw.rect(self.screen, green, (235, 255, 155, 50))
            TextSurf = self.font1.render("Move:", True, (255, 255, 255))
            TextRect = TextSurf.get_rect()
            TextRect.center = (312,283)
            self.screen.blit(TextSurf, TextRect)
            self.screen.blit(self.arrow_left,(400,250))
            self.screen.blit(self.arrow_right,(460,250))

            pygame.draw.rect(self.screen, green, (220, 330, 170, 50))
            TextSurf = self.font1.render("Shoot:", True, (255, 255, 255))
            TextRect = TextSurf.get_rect()
            TextRect.center = (305,358)
            self.screen.blit(TextSurf, TextRect)
            self.screen.blit(self.spacebar,(400,328))

            self.button("Back", 340, 490, 125, 50, red, bright_red, self.game_intro)
            pygame.display.update()

    # For Quit Button
    def gamequit(self):
        pygame.quit()
        quit()

    # for Checking Enemy list is empty or not
    def empty(self,seq):
        try:
            return all(map(self.empty, seq))
        except TypeError:
            return False

    # Main Game Loop(Game Play)
    def game_loop(self):
        self.__init__()
        clock = pygame.time.Clock()
        for x in range(1):
            self.moveEnemiesDown()
        while True:

            clock.tick(60)
            self.screen.fill((0, 0, 0))
            for event in pygame.event.get():
                if event.type == QUIT:
                    sys.exit()

            for enemy in self.enemies:
                for enemy in enemy:
                    self.screen.blit(pygame.transform.scale(self.enemySprites[enemy[0]][self.animationOn], (35, 35)),
                                     (enemy[1].x, enemy[1].y))
            self.screen.blit(self.player, (self.playerX, self.playerY))
            if self.bullet:
                pygame.draw.rect(self.screen, (52, 255, 0), self.bullet)
            for bullet in self.bullets:
                pygame.draw.rect(self.screen, (255, 255, 255), bullet)
            for b in self.barrierParticles:
                pygame.draw.rect(self.screen, (52, 255, 0), b)

            if self.empty(self.enemies) :
                self.string ="You Win!!!"
                self.game_end_screen()
            elif self.lives > 0:
                self.bulletUpdate()
                self.enemyUpdate()
                self.playerUpdate()
            elif self.lives == 0:
                self.string ="You Lose!!!"
                self.game_end_screen()
            self.screen.blit(self.font.render("Lives: {}".format(self.lives), -1, (255, 255, 255)), (20, 10))
            self.screen.blit(self.font.render("Score: {}".format(self.score), -1, (255, 255, 255)), (660, 10))
            pygame.display.update()

    # For Running the Thread of a class
    def run(self):

        # Background Sound
        mixer.music.load("assets/background.wav")
        mixer.music.play(-2)

        self.game_intro()


if __name__ == "__main__":
    # Actual Execution of Code
    SpaceInvaders().run()
